#include "hazel.h"

#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

class ExampleLayer : public Hazel::Layer
{
public:
	ExampleLayer()
		:Layer("ExampleLayer"), m_CameraControl(1280.0f/720.0f,true), m_SquareColor(0.2f,0.2f,0.8f)
	{
		m_VertexArray.reset(Hazel::VertexArray::Create());

		float vertics[3 * 7] = {
				-0.5f,-0.5f,0.f,1.0f,0.0f,0.0f,1.0f,
				 0.5f,-0.5f,0.f,0.0f,1.0f,0.0f,1.0f,
				 0.0f, 0.5f,0.f,0.0f,0.0f,1.0f,1.0f,
		};

		Hazel::Ref<Hazel::VertexBuffer> vertexbuffer;
		vertexbuffer.reset(Hazel::VertexBuffer::Create(vertics, sizeof(vertics)));

		Hazel::BufferLayout layout = {
		{ Hazel::ShaderDataType::Float3, "a_Position"},
		{ Hazel::ShaderDataType::Float4, "a_Color"},
		};

		vertexbuffer->SetLayout(layout);

		m_VertexArray->AddVertexBuffer(vertexbuffer);


		uint32_t indices[3] = { 0,1,2 };
		Hazel::Ref<Hazel::IndexBuffer> indexbuffer;
		indexbuffer.reset(Hazel::IndexBuffer::Create(indices, sizeof(indices) / sizeof(uint32_t)));
		m_VertexArray->SetIndexBuffer(indexbuffer);



		m_SquareVA.reset(Hazel::VertexArray::Create());

		float squareV[5 * 4] = {
				-0.5f,-0.5f,0.0f,0.0f,0.0f,
				 0.5f,-0.5f,0.0f,1.0f,0.0f,
				 0.5f, 0.5f,0.0f,1.0f,1.0f,
				-0.5f, 0.5f,0.0f,0.0f,1.0f,
				
		};

		Hazel::Ref<Hazel::VertexBuffer> squareVB;
		squareVB.reset(Hazel::VertexBuffer::Create(squareV, sizeof(squareV)));

		Hazel::BufferLayout squarelayout = {

		{ Hazel::ShaderDataType::Float3, "a_Position"},
		{ Hazel::ShaderDataType::Float2, "a_TexCoord"},

		};

		squareVB->SetLayout(squarelayout);

		m_SquareVA->AddVertexBuffer(squareVB);


		uint32_t squareI[6] = { 0,1,2,2,3,0 };
		Hazel::Ref<Hazel::IndexBuffer> squareIB;
		squareIB.reset(Hazel::IndexBuffer::Create(squareI, sizeof(squareI) / sizeof(uint32_t)));
		m_SquareVA->SetIndexBuffer(squareIB);

		/////////////////////////������////////////////////////////////
		std::string vertexSrc = R"(
			
			#version 330 core

			layout(location = 0) in vec3 a_Position;
			layout(location = 1) in vec4 a_Color;

			uniform mat4 u_ViewProjection;
			uniform mat4 u_Transform;

			out vec3 v_Position;
			out vec4 v_Color;

			void main()
			{
				v_Color = a_Color;
				v_Position = a_Position;
				gl_Position = u_ViewProjection * u_Transform * vec4(a_Position,1.0);	
			}
			
			)";

		std::string fragmentSrc = R"(
			
			#version 330 core

			layout(location = 0) out vec4 color;

			in vec3 v_Position;
			in vec4 v_Color;

			void main()
			{
				color = vec4(v_Position, 1.0);
				color = vec4(v_Color);
			}
			
			)";

		m_Shader = Hazel::Shader::Create("TriangleColorShader", vertexSrc, fragmentSrc);
		////////////////////////////������////////////////////////////////////
		std::string squarevertexSrc = R"(
			
			#version 330 core

			layout(location = 0) in vec3 a_Position;
			
		
			uniform mat4 u_ViewProjection;
			uniform mat4 u_Transform;

			

			void main()
			{
				
				gl_Position = u_ViewProjection * u_Transform * vec4(a_Position,1.0);	
			}
			
			)";

		std::string squarefragmentSrc = R"(
			
			#version 330 core

			layout(location = 0) out vec4 color;

			

			uniform vec3 u_Color; 			

			void main()
			{
				color = vec4(u_Color,1.0);
			}
			
			)";

		m_SquareShader = Hazel::Shader::Create("SquareColorShader",squarevertexSrc, squarefragmentSrc);

		////////////////////////////////����������//////////////////////
		auto textureshader = m_ShaderLibary.Load("assets/shaders/Texture.glsl");

		m_Texture = Hazel::Texture2D::Create("assets/textures/0.png");
        m_ChernoLogoTexture = Hazel::Texture2D::Create("assets/textures/ChernoLogo.png");


		std::dynamic_pointer_cast<Hazel::OpenGLShader>(textureshader)->Bind();
		std::dynamic_pointer_cast<Hazel::OpenGLShader>(textureshader)->UploadUniformI1("u_Texture", 0);

		///////////////////////////////////////////////////////////////
		
	}

	void OnUpdate(Hazel::TimeStep ts) override
	{
		m_CameraControl.OnUpdate(ts);



		Hazel::RenderCommand::SetClearColor({ 0.1f, 0.2f, 0.1f, 1 });
		Hazel::RenderCommand::Clear();

		

		std::dynamic_pointer_cast<Hazel::OpenGLShader>(m_SquareShader)->Bind();
		std::dynamic_pointer_cast<Hazel::OpenGLShader>(m_SquareShader)->UploadUniformF3("u_Color", m_SquareColor);

		Hazel::Renderer::BeginScene(m_CameraControl.GetCamera());

		
		glm::mat4 scale = glm::scale(glm::mat4(1.0f),glm::vec3(0.1f));
		

		for (int i = 0; i < 20; i++)
		{
			for (int j = 0; j < 20; j++)
			{
				glm::vec3 pos = {i * 0.11f, j* 0.11f,0.0f};
				glm::mat4 translate = glm::translate(glm::mat4(1.0), pos) * scale;
				Hazel::Renderer::Submit(m_SquareShader, m_SquareVA, translate);
			}
		}

		auto textureshader = m_ShaderLibary.Get("Texture");

		m_Texture->Bind();
		Hazel::Renderer::Submit(textureshader, m_SquareVA, glm::scale(glm::mat4(1.0f), glm::vec3(1.0f)));

		m_ChernoLogoTexture->Bind();
		Hazel::Renderer::Submit(textureshader, m_SquareVA, glm::scale(glm::mat4(1.0f), glm::vec3(1.0f)));

		//������
		//Hazel::Renderer::Submit(m_Shader, m_VertexArray);

		Hazel::Renderer::EndScene();
	}

	void OnEvent(Hazel::Event& e) override
	{
		m_CameraControl.OnEvent(e);
	}

	virtual void OnImGuiRender() override
	{
		ImGui::Begin("Setting Colors");
		ImGui::ColorEdit3("Square Color", glm::value_ptr(m_SquareColor));
		ImGui::End();
	}

private:
	Hazel::ShaderLibary m_ShaderLibary;
	Hazel::Ref<Hazel::Shader> m_Shader;
	Hazel::Ref<Hazel::VertexArray> m_VertexArray;

	Hazel::Ref<Hazel::Shader> m_SquareShader;
	Hazel::Ref<Hazel::VertexArray> m_SquareVA;

	Hazel::Ref<Hazel::Texture2D> m_Texture,m_ChernoLogoTexture;

	Hazel::OrthoGraphicCameraControl m_CameraControl;

	glm::vec3 m_SquarePosition;
	float m_SquarePositionMove = 5.0f;

	glm::vec3 m_SquareColor;
};

class Sandbox : public Hazel::Application
{
public:
	Sandbox() {
		PushOverlay(new ExampleLayer());
		
	}
	~Sandbox() {

	}
};

Hazel::Application* Hazel::CreateAPP(){

	return new Sandbox();
}