#pragma once

#include "Hazel/Core/Input.h"

namespace Hazel {

	class WindowsInput : public Input
	{
	protected:

		virtual inline bool IsKeyCodePressedImpl(int keycode)override;
		virtual inline bool IsMouseButtonPressedImpl(int button)override;
		virtual inline std::pair<float, float> GetMousePositionImpl() override;
		virtual inline float GetMouseXImpl() override;
		virtual inline float GetMouseYImpl() override;

	private:

	};
}