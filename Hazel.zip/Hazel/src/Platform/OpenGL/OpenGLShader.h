#pragma once
#include "Hazel/Renderer/Shader.h"
#include <glm/glm.hpp>
namespace Hazel {


	class HAZEL_API OpenGLShader : public Shader
	{
	public:
		OpenGLShader(const std::string& name,const std::string& vertexSrc, const std::string& fragmentSrc);
		OpenGLShader(const std::string& filepath);
		virtual ~OpenGLShader();
		virtual void Bind() const override;
		virtual void Unbind() const override;

		virtual inline const std::string& GetName() const override { return m_Name; };

		void UploadUniformMat4(const std::string& name, const glm::mat4& matrix);
		void UploadUniformMat3(const std::string& name, const glm::mat3& matrix);

		void UploadUniformF4(const std::string& name, const glm::vec4& value);
		void UploadUniformF3(const std::string& name, const glm::vec3& value);
		void UploadUniformF2(const std::string& name, const glm::vec2& value);
		void UploadUniformF1(const std::string& name, const float& value);

		void UploadUniformI1(const std::string& name, const int& value);

	private:

		std::string ReadFile(const std::string& filepath);
		std::unordered_map<GLenum, std::string> Preprocess(const std::string& source);
		void Complie(const std::unordered_map<GLenum, std::string>& shaderSource);
		
	private:
		uint32_t m_RendererID;
		std::string m_Name;
	};
}

