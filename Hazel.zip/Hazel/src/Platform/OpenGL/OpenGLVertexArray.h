#pragma once
#include "Hazel/Renderer/VertexArray.h"

namespace Hazel {

	class OpenGLVertexArray : public VertexArray
	{
	public:
		OpenGLVertexArray();
		virtual ~OpenGLVertexArray();

		virtual void Bind() const override;
		virtual void Unbind() const override;

		virtual void AddVertexBuffer(Ref<VertexBuffer>& vertexbuffer) override;
		virtual void SetIndexBuffer(Ref<IndexBuffer>& indexbuffer) override;

		virtual std::vector<Ref<VertexBuffer>> GetVertexBuffers() const override {
			return m_vertexbuffers; };
		virtual Ref<IndexBuffer> SetIndexBuffer() const override {
			return m_indexbuffer;
		};

	private:
		std::vector<Ref<VertexBuffer>> m_vertexbuffers;
		Ref<IndexBuffer> m_indexbuffer;
		uint32_t m_RendererID;
	};

}
