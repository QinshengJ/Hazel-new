#pragma once

#include "hzpch.h"
#include "Layer.h"

namespace Hazel {

	class HAZEL_API LayerStack : public Layer
	{
	public:
		LayerStack();
		~LayerStack();

		void PushLayer(Layer* layer);
		void PushOverLay(Layer* overlay);
		void PopLayer(Layer* layer);
		void PopOverLay(Layer* overlay);

		std::vector<Layer*>::iterator begin() { return m_Layer.begin(); }
		std::vector<Layer*>::iterator end() { return m_Layer.end(); }

	private:
		std::vector<Layer*> m_Layer;
		unsigned int m_InsertLayerIndex = 0;
	};

}