#pragma once
#include "Core.h"
#include "Hazel/Event/Event.h"
#include "TimeStep.h"

namespace Hazel
{
	class HAZEL_API Layer
	{
	public:
		Layer(const std::string& name = "Layer");
		virtual ~Layer();

		virtual void OnEvent(Event& e) {}
		virtual void OnUpdate(TimeStep ts) {}
		virtual void OnAttach(){}
		virtual void OnDetach(){}
		virtual void OnImGuiRender(){}

	protected:
		std::string m_debugName;
	};
}