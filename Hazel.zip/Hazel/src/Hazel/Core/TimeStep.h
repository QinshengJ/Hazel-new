#pragma once
#include "Core.h"

namespace Hazel {

	class HAZEL_API TimeStep
	{
	public:
		 TimeStep(float time = 0.0f)
			 :m_Time(time)
		 {}

		 operator float() const { return m_Time; }

		 float GetSecond() const { return m_Time; }
		 float GetMilliSecond() const { return m_Time*1000.0f; }

	private:
		float m_Time;
	};

}