#include "hzpch.h"
#include "Layer.h"


namespace Hazel {

	Layer::Layer(const std::string& name)
		:m_debugName(name)
	{}

	Layer::~Layer()
	{}

}