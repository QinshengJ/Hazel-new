#pragma once


#ifdef HZ_PLATFORM_WINDOWS

extern Hazel::Application* Hazel::CreateAPP();


int main() {
	
	Hazel::Log::Init();
	Hazel::Log::GetCoreLogger()->trace("welcome to Hazel engine!");
	Hazel::Log::GetClientLogger()->trace("welcome to Hazel engine app!");

	auto app = Hazel::CreateAPP();
	app->Run();
	delete app;

}

#endif