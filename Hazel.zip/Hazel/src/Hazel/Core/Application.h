#pragma once

#include "Core.h"
#include "Window.h"
#include "Hazel/Event/ApplicationEvent.h"
#include "LayerStack.h"
#include "Hazel/ImGui/ImguiLayer.h"
#include "TimeStep.h"


namespace Hazel {
	class HAZEL_API Application
	{
	public:
		Application();
		~Application();
		void Run();

		void OnEvent(Event& e);

		void PushLayer(Layer* layer);
		void PushOverlay(Layer* overlay);

		inline Window& GetWindow() { return *m_window; }
		static inline Application& Get() { return *s_Instance; }

	private:
		bool OnWindowClosed(WindowCloseEvent& e);
		bool OnWindowResized(WindowResizeEvent& e);
	private:
		Scope<Window> m_window;
		ImguiLayer* m_ImGuiLayer;
		bool m_Running = true;
		bool m_Minimized = false;
		LayerStack m_layerstack;
		static Application* s_Instance;

		float m_LastFrameTime = 0.0f;
	};

	Application* CreateAPP();
}


