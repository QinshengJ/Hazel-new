#pragma once

#include "hzpch.h"
#include "Hazel/Core/Core.h"
#include "Buffer.h"

namespace Hazel {

	class HAZEL_API VertexArray
	{
	public:
		virtual ~VertexArray() {}

		virtual void Bind() const = 0;
		virtual void Unbind() const = 0;

		virtual void AddVertexBuffer(Ref<VertexBuffer>& vertexbuffer) = 0;
		virtual void SetIndexBuffer(Ref<IndexBuffer>& indexbuffer) = 0;

		virtual std::vector<Ref<VertexBuffer>> GetVertexBuffers() const = 0;
		virtual Ref<IndexBuffer> SetIndexBuffer() const = 0;

		static VertexArray* Create();
	};

}
