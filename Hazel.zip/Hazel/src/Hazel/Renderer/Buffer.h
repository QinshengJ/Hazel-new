#pragma once

#include "Hazel/Core/Core.h"

namespace Hazel {



	enum class ShaderDataType
	{
		None = 0, Float, Float2, Float3, Float4, Mat3, Mat4, Int, Int2, Int3, Int4, Bool,
	};


	static uint32_t ShaderDataTypeSize(ShaderDataType& type)
	{
		switch (type)
		{
			case ShaderDataType::Float:      return 4;
			case ShaderDataType::Float2:     return 4 * 2;
			case ShaderDataType::Float3:     return 4 * 3;
			case ShaderDataType::Float4:     return 4 * 4;
			case ShaderDataType::Mat3:       return 4 * 3 * 3;
			case ShaderDataType::Mat4:       return 4 * 4 * 4;
			case ShaderDataType::Int:        return 4 ;
			case ShaderDataType::Int2:       return 4 * 2;
			case ShaderDataType::Int3:       return 4 * 3;
			case ShaderDataType::Int4:       return 4 * 4;
			case ShaderDataType::Bool:       return 1;
		}
		HZ_CORE_ASSERT(false,"Unknow Shaderdatatype");
		return 0;
	}


	struct HAZEL_API BufferElements
	{
		std::string Name;
		uint32_t Size;
		uint32_t Offsize;
		bool Normalized;
		ShaderDataType Type;

		BufferElements(){}
		BufferElements(ShaderDataType type, const std::string& name,bool normalized = false)
			:Name(name), Type(type),Size(ShaderDataTypeSize(type)), Offsize(0), Normalized(normalized)
		{}

		uint32_t GetElementCount() const
		{
			switch (Type)
			{
			case ShaderDataType::Float:      return 1;
			case ShaderDataType::Float2:     return 2;
			case ShaderDataType::Float3:     return 3;
			case ShaderDataType::Float4:     return 4;
			case ShaderDataType::Mat3:       return 3 * 3;
			case ShaderDataType::Mat4:       return 4 * 4;
			case ShaderDataType::Int:        return 1;
			case ShaderDataType::Int2:       return 2;
			case ShaderDataType::Int3:       return 3;
			case ShaderDataType::Int4:       return 4;
			case ShaderDataType::Bool:       return 1;
			}
			HZ_CORE_ASSERT(false, "Unknow Shaderdatatype");
			return 0;
		}

	};


	class HAZEL_API BufferLayout
	{
	public:
		BufferLayout(){}
		BufferLayout(const std::initializer_list<BufferElements> elements)
			:m_Elements(elements)
		{
			CalculateOffsetAndStride();
		}

		inline uint32_t GetStride()const { return m_Stride; }
		inline const std::vector<BufferElements>& GetElements() const { return m_Elements; }

		std::vector<BufferElements>::iterator begin() { return m_Elements.begin(); }
		std::vector<BufferElements>::iterator end() { return m_Elements.end(); }

		std::vector<BufferElements>::const_iterator begin()const { return m_Elements.begin(); }
		std::vector<BufferElements>::const_iterator end()const { return m_Elements.end(); }

	private:
		void CalculateOffsetAndStride()
		{
			int offsize = 0;
			m_Stride = 0;
			for (auto& element : m_Elements)
			{
				element.Offsize = offsize;
				offsize += element.Size;
				m_Stride += element.Size;
			}
		}
	private:
		std::vector<BufferElements> m_Elements;
		uint32_t m_Stride = 0;
	};

	class HAZEL_API VertexBuffer
	{
	public:
		virtual ~VertexBuffer(){}

		virtual void Bind() const = 0;
		virtual void Unbind() const = 0;
	
		inline virtual void SetLayout(BufferLayout& layout) = 0;
		inline virtual const BufferLayout GetLayOut() const = 0;

		static VertexBuffer* Create(float* vertices, uint32_t size);
	};

	class HAZEL_API IndexBuffer
	{
	public:
		virtual ~IndexBuffer(){}
		virtual void Bind() const = 0;
		virtual void Unbind() const = 0;
		virtual uint32_t GetCount() const = 0;
		static IndexBuffer* Create(uint32_t* indices, uint32_t size);
	};

}

