#include "hzpch.h"
#include "OrthoGraphicCameraControl.h"
#include "Core/Input.h"
#include "Core/InputKeyCodes.h"

namespace Hazel {

	OrthoGraphicCameraControl::OrthoGraphicCameraControl(float aspectRatio, bool rotation)
		:m_AspectRatio(aspectRatio),m_Camera(-m_AspectRatio*m_ZoomLevel, m_AspectRatio* m_ZoomLevel,-m_ZoomLevel, m_ZoomLevel),
		m_Rotaion(rotation)
	{
	}

	void OrthoGraphicCameraControl::OnUpdate(TimeStep& ts)
	{
		HZ_TRACE("Delta time : {0} s  ({1} ms)", ts.GetSecond(), ts.GetMilliSecond());

		if (Hazel::Input::IsKeyCodePressed(HZ_KEY_A))
			m_CameraPosition.x -= m_CameraPositionMove * ts;

		else if (Hazel::Input::IsKeyCodePressed(HZ_KEY_D))
			m_CameraPosition.x += m_CameraPositionMove * ts;

		if (Hazel::Input::IsKeyCodePressed(HZ_KEY_S))
			m_CameraPosition.y -= m_CameraPositionMove * ts;

		else if (Hazel::Input::IsKeyCodePressed(HZ_KEY_W))
			m_CameraPosition.y += m_CameraPositionMove * ts;

		if (m_Rotaion)
		{
			if (Hazel::Input::IsKeyCodePressed(HZ_KEY_Q))
				m_CameraRotation += m_CameraRotationMove * ts;

			else if (Hazel::Input::IsKeyCodePressed(HZ_KEY_E))
				m_CameraRotation -= m_CameraRotationMove * ts;
			m_Camera.SetRotation(m_CameraRotation);
		}

		m_Camera.SetPosition(m_CameraPosition);
		m_CameraPositionMove = m_ZoomLevel;
	}

	void OrthoGraphicCameraControl::OnEvent(Event& e)
	{
		EventDispatcher dispatcher(e);
		dispatcher.Dispatch<MouseScrolledEvent>(HZ_EVENT_BIND_FN(OrthoGraphicCameraControl::OnMouseScrolled));
		dispatcher.Dispatch<WindowResizeEvent>(HZ_EVENT_BIND_FN(OrthoGraphicCameraControl::OnWindowResized));
	}

	bool OrthoGraphicCameraControl::OnMouseScrolled(MouseScrolledEvent& e)
	{
		m_ZoomLevel -= e.GetYOffset() * 0.25f;
		m_ZoomLevel = std::max(m_ZoomLevel, 0.05f);
		m_Camera.SetProjection(-m_AspectRatio * m_ZoomLevel, m_AspectRatio * m_ZoomLevel, -m_ZoomLevel, m_ZoomLevel);
		return false;
	}

	bool OrthoGraphicCameraControl::OnWindowResized(WindowResizeEvent& e)
	{
		m_AspectRatio = (float)e.GetWidth() / (float)e.GetHeight();
		m_Camera.SetProjection(-m_AspectRatio * m_ZoomLevel, m_AspectRatio * m_ZoomLevel, -m_ZoomLevel, m_ZoomLevel);

		return false;
	}

}