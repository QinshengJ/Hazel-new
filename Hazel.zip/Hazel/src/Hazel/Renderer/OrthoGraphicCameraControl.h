#pragma once

#include "OrthoGraphicCamera.h"
#include "Hazel/Core/TimeStep.h"

#include "Hazel/Event/ApplicationEvent.h"
#include "Hazel/Event/MouseEvent.h"

namespace Hazel {

	class OrthoGraphicCameraControl
	{
	public:
		OrthoGraphicCameraControl(float aspectRatio, bool rotation = false);

		void OnUpdate(TimeStep& ts);
		void OnEvent(Event& e);

		OrthoGraphicCamera& GetCamera() { return m_Camera; }
		const OrthoGraphicCamera& GetCamera() const { return m_Camera; }
	private:

		bool OnMouseScrolled(MouseScrolledEvent& e);
		bool OnWindowResized(WindowResizeEvent & e);
	private:
		OrthoGraphicCamera m_Camera;
		float m_AspectRatio;
		float m_ZoomLevel = 1.0f;
		bool m_Rotaion;

		glm::vec3 m_CameraPosition = { 1.0f,1.0f,1.0f };
		float m_CameraPositionMove = 5.0f;

		float m_CameraRotation = 0.0f;
		float m_CameraRotationMove = 180.0f;
	};

}