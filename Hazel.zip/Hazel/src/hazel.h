#pragma once

//Ϊ�˿ͻ���ʹ��
#include "hzpch.h"
#include "Hazel/Event/Event.h"
#include "Hazel/Core/Application.h"
#include "Hazel/Core/Window.h"


#include "Hazel/Core/TimeStep.h"
#include "Hazel/Core/LayerStack.h"
#include "Hazel/ImGui/ImguiLayer.h"
#include "Hazel/Renderer/OrthoGraphicCameraControl.h"

#include "Hazel/Core/Input.h"
#include "Hazel/Core/InputKeyCodes.h"
#include "Hazel/Core/InputMouseCodes.h"


//��Ⱦ
#include "Hazel/Renderer/Renderer.h"
#include "Hazel/Renderer/Shader.h"
#include "Hazel/Renderer/Buffer.h"
#include "Hazel/Renderer/VertexArray.h"
#include "Hazel/Renderer/OrthoGraphicCamera.h"
#include "Hazel/Renderer/Texture.h"

#include "Platform/OpenGL/OpenGLShader.h"

//-----------���-------------
#include "Hazel/Core/EntryPoint.h"
//----------------------------